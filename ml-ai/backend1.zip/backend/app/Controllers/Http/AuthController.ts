import type { HttpContextContract } from '@ioc:Adonis/Core/HttpContext'
import AuthValidator from 'App/Validators/AuthValidator'

export default class AuthController {
  public async login({ request, auth, response }: HttpContextContract) {
    let data = await request.validate(AuthValidator)
    let val = await auth.attempt(data.email, data.password)
    
    return response.send({ message: 'Logged In', data: val })
  }

  public async logout({}: HttpContextContract) {}
}
